PRAGMA e;select lower(0);select lower(0)"a",""GROUP BY a ORDER BY a;
